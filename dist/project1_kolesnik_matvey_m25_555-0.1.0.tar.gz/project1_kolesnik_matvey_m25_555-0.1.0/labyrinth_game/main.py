#!/usr/bin/env python 3

def main():
    print("Первая попытка запустить проект!")

if __name__ == "__main__":
    main()
